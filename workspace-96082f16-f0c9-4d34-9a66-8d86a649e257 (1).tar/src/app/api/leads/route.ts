import { NextRequest, NextResponse } from 'next/server';

// In-memory storage for demo/fallback when database is not available
const leadsMemory: Array<{
  id: string;
  studentName: string;
  country: string;
  curriculum: string;
  level: string;
  currentGrade: string;
  targetGrade: string;
  whatsapp: string;
  email: string;
  message: string | null;
  status: string;
  createdAt: Date;
}> = [];

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const {
      studentName,
      country,
      curriculum,
      level,
      currentGrade,
      targetGrade,
      whatsapp,
      email,
      message
    } = body;

    // Validate required fields
    if (!studentName || !country || !curriculum || !level || !whatsapp || !email) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Generate a unique ID
    const leadId = `lead_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Try to use database if available
    try {
      const { db } = await import('@/lib/db');
      const lead = await db.lead.create({
        data: {
          studentName,
          country,
          curriculum,
          level,
          currentGrade: currentGrade || 'Not specified',
          targetGrade: targetGrade || 'Not specified',
          whatsapp,
          email,
          message: message || null,
          status: 'new'
        }
      });

      return NextResponse.json({
        success: true,
        message: 'Thank you! We will contact you within 24 hours.',
        leadId: lead.id
      });
    } catch {
      // Database not available, fall back to memory
      console.log('Database not available, using memory storage');
    }

    // Fallback to in-memory storage
    leadsMemory.push({
      id: leadId,
      studentName,
      country,
      curriculum,
      level,
      currentGrade: currentGrade || 'Not specified',
      targetGrade: targetGrade || 'Not specified',
      whatsapp,
      email,
      message: message || null,
      status: 'new',
      createdAt: new Date()
    });

    console.log('Lead saved to memory:', { studentName, email, country });

    return NextResponse.json({
      success: true,
      message: 'Thank you! We will contact you within 24 hours.',
      leadId
    });
  } catch (error) {
    console.error('Error creating lead:', error);
    return NextResponse.json(
      { error: 'Failed to submit form. Please try again.' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Try to use database if available
    try {
      const { db } = await import('@/lib/db');
      const leads = await db.lead.findMany({
        orderBy: { createdAt: 'desc' },
        take: 50
      });
      
      return NextResponse.json({ leads, source: 'database' });
    } catch {
      // Database not available, fall back to memory
      console.log('Database not available, using memory storage');
    }

    // Fallback to in-memory storage
    return NextResponse.json({ 
      leads: leadsMemory.slice(-50).reverse(), 
      source: 'memory' 
    });
  } catch (error) {
    console.error('Error fetching leads:', error);
    return NextResponse.json(
      { error: 'Failed to fetch leads' },
      { status: 500 }
    );
  }
}
