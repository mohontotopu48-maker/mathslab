'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// Import all sections
import LoadingScreen from '@/components/ui/custom/LoadingScreen';
import Navigation from '@/components/sections/Navigation';
import HeroSection from '@/components/sections/HeroSection';
import AboutSection from '@/components/sections/AboutSection';
import CoursesSection from '@/components/sections/CoursesSection';
import InternationalSection from '@/components/sections/InternationalSection';
import ResultsSection from '@/components/sections/ResultsSection';
import MethodologySection from '@/components/sections/MethodologySection';
import WhyChooseSection from '@/components/sections/WhyChooseSection';
import LeadFormSection from '@/components/sections/LeadFormSection';
import Footer from '@/components/sections/Footer';
import WhatsAppButton from '@/components/ui/custom/WhatsAppButton';

export default function Home() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading time for assets
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <LoadingScreen isLoading={isLoading} />
      
      <AnimatePresence mode="wait">
        {!isLoading && (
          <motion.main
            key="main-content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="min-h-screen bg-[#0a1628] text-white overflow-x-hidden"
          >
            <Navigation />
            <HeroSection />
            <AboutSection />
            <CoursesSection />
            <InternationalSection />
            <ResultsSection />
            <MethodologySection />
            <WhyChooseSection />
            <LeadFormSection />
            <Footer />
            <WhatsAppButton />
          </motion.main>
        )}
      </AnimatePresence>
    </>
  );
}
