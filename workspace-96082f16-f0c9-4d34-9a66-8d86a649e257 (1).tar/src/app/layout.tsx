import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL('https://mathslab.com'),
  title: "Maths Lab | Expert O & A Level Mathematics Tutor - Cambridge & Edexcel",
  description: "Master O Level & A Level Mathematics with expert tutoring. Cambridge & Edexcel specialist with 10+ years experience, 1000+ students mentored, and 95% A-A* success rate. International online classes available.",
  keywords: [
    "O Level Math Tutor Online",
    "A Level Math Tutor International",
    "Cambridge Mathematics Tutor",
    "Edexcel A Level Statistics Tutor",
    "Online A Level Coaching",
    "Mathematics tutor UK",
    "Mathematics tutor UAE",
    "Mathematics tutor Singapore",
    "Mathematics tutor Malaysia",
    "A Level Maths preparation",
    "O Level Maths preparation",
    "Cambridge IGCSE maths tutor",
    "Edexcel maths tutor online",
    "International maths tutor"
  ],
  authors: [{ name: "Maths Lab" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Maths Lab | Expert O & A Level Mathematics Tutor",
    description: "Master O Level & A Level Mathematics with expert tutoring. Cambridge & Edexcel specialist with 10+ years experience. International online classes.",
    url: "https://mathslab.com",
    siteName: "Maths Lab",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Maths Lab | Expert O & A Level Mathematics Tutor",
    description: "Master O Level & A Level Mathematics with expert tutoring. Cambridge & Edexcel specialist.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
