'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Target, Brain, FileCheck, Clock, BarChart3, ChevronRight } from 'lucide-react';

const methodologySteps = [
  {
    step: 1,
    title: 'Diagnostic Assessment',
    description: 'Evaluate your current understanding and identify knowledge gaps through comprehensive testing and analysis.',
    icon: Target,
    color: 'from-[#d4a574] to-[#b8956a]',
  },
  {
    step: 2,
    title: 'Concept Building',
    description: 'Build strong foundations with clear explanations, visual learning techniques, and real-world applications.',
    icon: Brain,
    color: 'from-[#10b981] to-[#059669]',
  },
  {
    step: 3,
    title: 'Intensive Practice',
    description: 'Apply concepts through carefully curated problem sets, past paper questions, and timed exercises.',
    icon: FileCheck,
    color: 'from-[#3b82f6] to-[#2563eb]',
  },
  {
    step: 4,
    title: 'Mock Exams',
    description: 'Simulate real exam conditions to build confidence, improve time management, and reduce anxiety.',
    icon: Clock,
    color: 'from-[#f59e0b] to-[#d97706]',
  },
  {
    step: 5,
    title: 'Performance Feedback',
    description: 'Receive detailed analysis of strengths and areas for improvement with actionable insights and strategies.',
    icon: BarChart3,
    color: 'from-[#8b5cf6] to-[#7c3aed]',
  },
];

export default function MethodologySection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="methodology" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a1628] via-[#0f2847]/30 to-[#0a1628]" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#d4a574]/20 to-transparent" />

      {/* Decorative elements */}
      <div className="absolute top-1/4 -left-32 w-64 h-64 bg-[#8b5cf6]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-64 h-64 bg-[#3b82f6]/5 rounded-full blur-3xl" />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-[#d4a574]/10 text-[#d4a574] text-sm font-medium mb-4">
            Our Approach
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Teaching{' '}
            <span className="bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
              Methodology
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            A proven 5-step approach to academic success
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-[#d4a574] via-[#d4a574]/30 to-transparent md:-translate-x-px" />

          <div className="space-y-12">
            {methodologySteps.map((step, index) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.2 + index * 0.15 }}
                className={`relative flex flex-col md:flex-row items-start gap-6 md:gap-12 ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Step number & icon */}
                <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 z-10">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    className={`w-14 h-14 rounded-xl bg-gradient-to-br ${step.color} flex items-center justify-center shadow-lg`}
                  >
                    <step.icon className="w-7 h-7 text-white" />
                  </motion.div>
                </div>

                {/* Content card */}
                <div className={`flex-1 ml-20 md:ml-0 ${index % 2 === 0 ? 'md:pr-[calc(50%+3rem)]' : 'md:pl-[calc(50%+3rem)]'}`}>
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="p-6 rounded-2xl bg-[#1a365d]/30 border border-[#d4a574]/10 hover:border-[#d4a574]/30 transition-all duration-300"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <span className={`px-3 py-1 rounded-lg bg-gradient-to-r ${step.color} text-white text-xs font-bold`}>
                        Step {step.step}
                      </span>
                      <ChevronRight className="w-4 h-4 text-[#d4a574]/50" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">{step.title}</h3>
                    <p className="text-gray-400">{step.description}</p>
                  </motion.div>
                </div>

                {/* Empty space for alternating layout */}
                <div className="hidden md:block flex-1" />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1 }}
          className="mt-16 text-center"
        >
          <p className="text-gray-500 mb-4">Ready to start your journey to academic excellence?</p>
          <motion.a
            href="#contact"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] text-[#0a1628] font-semibold shadow-lg shadow-[#d4a574]/20 hover:shadow-[#d4a574]/30 transition-all"
          >
            Start Your Journey
            <ChevronRight className="w-5 h-5" />
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}
