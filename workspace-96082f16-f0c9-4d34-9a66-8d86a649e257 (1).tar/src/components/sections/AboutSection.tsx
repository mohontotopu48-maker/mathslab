'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { GraduationCap, BookOpen, Target, Users, Award, Clock } from 'lucide-react';
import GlassCard from '@/components/ui/custom/GlassCard';

const timelineEvents = [
  { year: '2014', title: 'Teaching Journey Begins', desc: 'Started tutoring O Level students with a passion for making mathematics accessible' },
  { year: '2017', title: 'A Level Expertise', desc: 'Expanded to A Level Mathematics & Statistics with specialized focus on exam techniques' },
  { year: '2020', title: 'Global Reach', desc: 'Launched international online classes serving students from UK, UAE, Singapore & more' },
  { year: '2024', title: '1000+ Milestone', desc: 'Celebrated mentoring over 1000 students with 95% achieving A-A* grades' },
];

const highlights = [
  { icon: BookOpen, title: 'Cambridge & Edexcel Expert', desc: 'Complete curriculum mastery' },
  { icon: Target, title: 'Exam-Focused Approach', desc: 'Proven techniques for A* results' },
  { icon: Users, title: 'International Experience', desc: 'Students from 15+ countries' },
];

export default function AboutSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a1628] via-[#0f2847]/30 to-[#0a1628]" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#d4a574]/20 to-transparent" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-[#d4a574]/10 text-[#d4a574] text-sm font-medium mb-4">
            About The Tutor
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Your Partner in{' '}
            <span className="bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
              Academic Excellence
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Building conceptual clarity, confidence, and top exam performance through personalized guidance
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Profile Card */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <GlassCard className="p-8 md:p-10" glow>
              <div className="flex flex-col items-center md:items-start">
                {/* Avatar */}
                <motion.div
                  whileHover={{ scale: 1.05, rotate: 5 }}
                  className="w-32 h-32 rounded-2xl bg-gradient-to-br from-[#d4a574] to-[#e8c9a0] flex items-center justify-center shadow-xl shadow-[#d4a574]/20 mb-6"
                >
                  <GraduationCap className="w-16 h-16 text-[#0a1628]" />
                </motion.div>

                {/* Info */}
                <div className="text-center md:text-left">
                  <h3 className="text-2xl font-bold text-white mb-1">Expert Mathematics Tutor</h3>
                  <p className="text-[#d4a574] font-medium mb-4">O & A Level Specialist</p>
                  <p className="text-gray-400 mb-6 leading-relaxed">
                    With over a decade of experience, I have helped students from around the world achieve their academic goals. 
                    My approach combines deep conceptual understanding with proven exam strategies.
                  </p>

                  {/* Highlights */}
                  <div className="space-y-4">
                    {highlights.map((item, index) => (
                      <motion.div
                        key={item.title}
                        initial={{ opacity: 0, x: -20 }}
                        animate={isInView ? { opacity: 1, x: 0 } : {}}
                        transition={{ delay: 0.4 + index * 0.1 }}
                        className="flex items-center gap-4 group"
                      >
                        <div className="w-12 h-12 rounded-xl bg-[#d4a574]/10 flex items-center justify-center group-hover:bg-[#d4a574]/20 transition-colors">
                          <item.icon className="w-6 h-6 text-[#d4a574]" />
                        </div>
                        <div>
                          <p className="font-semibold text-white">{item.title}</p>
                          <p className="text-sm text-gray-500">{item.desc}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </GlassCard>
          </motion.div>

          {/* Timeline */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h3 className="text-xl font-bold text-white mb-8 flex items-center gap-3">
              <Award className="w-6 h-6 text-[#d4a574]" />
              Professional Journey
            </h3>

            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-6 top-0 bottom-0 w-px bg-gradient-to-b from-[#d4a574] via-[#d4a574]/50 to-transparent" />

              <div className="space-y-8">
                {timelineEvents.map((event, index) => (
                  <motion.div
                    key={event.year}
                    initial={{ opacity: 0, y: 20 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ delay: 0.4 + index * 0.15 }}
                    className="relative flex gap-6 group"
                  >
                    {/* Year dot */}
                    <div className="relative z-10">
                      <motion.div
                        whileHover={{ scale: 1.2 }}
                        className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#d4a574] to-[#e8c9a0] flex items-center justify-center shadow-lg shadow-[#d4a574]/20"
                      >
                        <span className="text-sm font-bold text-[#0a1628]">{event.year}</span>
                      </motion.div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 glass-card p-5 rounded-xl bg-[#1a365d]/30 border border-[#d4a574]/10 group-hover:border-[#d4a574]/30 transition-all duration-300">
                      <h4 className="font-semibold text-white mb-1">{event.title}</h4>
                      <p className="text-sm text-gray-400">{event.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.8 }}
              className="mt-10 grid grid-cols-3 gap-4"
            >
              {[
                { value: '10+', label: 'Years' },
                { value: '1000+', label: 'Students' },
                { value: '95%', label: 'Success' },
              ].map((stat) => (
                <div key={stat.label} className="text-center p-4 rounded-xl bg-[#1a365d]/30 border border-[#d4a574]/10">
                  <div className="text-2xl font-bold bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
                    {stat.value}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{stat.label}</p>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
