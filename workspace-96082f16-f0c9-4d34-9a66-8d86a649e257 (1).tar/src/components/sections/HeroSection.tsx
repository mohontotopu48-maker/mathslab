'use client';

import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, Play, Globe, Users, Award, Clock, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import FloatingMath from '@/components/ui/custom/FloatingMath';
import AnimatedCounter from '@/components/ui/custom/AnimatedCounter';

export default function HeroSection() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 150]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);

  const trustIndicators = [
    { value: 10, suffix: '+', label: 'Years Experience', icon: Clock },
    { value: 1000, suffix: '+', label: 'Students Mentored', icon: Users },
    { value: 95, suffix: '%', label: 'A-A* Success Rate', icon: Award },
    { value: 15, suffix: '+', label: 'Countries Reached', icon: Globe },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background layers */}
      <div className="absolute inset-0">
        <motion.div style={{ y }} className="absolute inset-0 bg-gradient-to-b from-[#0a1628] via-[#0f2847]/80 to-[#0a1628]" />
        
        {/* Animated gradient orbs */}
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-[#d4a574]/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-[#1a365d]/40 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            scale: [1, 1.3, 1],
            opacity: [0.2, 0.4, 0.2]
          }}
          transition={{ duration: 12, repeat: Infinity }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#d4a574]/5 rounded-full blur-3xl"
        />

        {/* Grid pattern overlay */}
        <div 
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(#d4a574 1px, transparent 1px), linear-gradient(90deg, #d4a574 1px, transparent 1px)`,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      <FloatingMath />

      {/* Content */}
      <motion.div 
        style={{ opacity }}
        className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
      >
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-[#1a365d] to-[#0f2847] border border-[#d4a574]/20 mb-8"
          >
            <Sparkles className="w-4 h-4 text-[#d4a574]" />
            <span className="text-sm text-[#d4a574] font-medium">International Online Classes</span>
            <Globe className="w-4 h-4 text-[#d4a574]" />
          </motion.div>

          {/* Main Heading */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-bold mb-6 leading-tight">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="block text-white"
            >
              Master{' '}
              <span className="bg-gradient-to-r from-[#d4a574] via-[#e8c9a0] to-[#d4a574] bg-clip-text text-transparent">
                O & A Level
              </span>
            </motion.span>
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="block text-white mt-2"
            >
              Mathematics
            </motion.span>
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="block text-gray-400 text-2xl sm:text-3xl md:text-4xl lg:text-5xl mt-4 font-normal"
            >
              with Global Expert Guidance
            </motion.span>
          </h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto mb-10"
          >
            <span className="text-[#d4a574]">Cambridge</span> & <span className="text-[#d4a574]">Edexcel</span> Specialist | 
            International Online Classes | 
            <span className="text-white"> Proven Exam Results</span>
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="flex flex-col sm:flex-row gap-4 justify-center mb-16"
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                size="lg"
                className="group relative bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] text-[#0a1628] font-bold text-lg px-10 py-7 rounded-xl overflow-hidden shadow-xl shadow-[#d4a574]/20 hover:shadow-[#d4a574]/40 transition-all duration-300"
                asChild
              >
                <a href="#contact">
                  <span className="relative z-10 flex items-center gap-2">
                    Book Free Trial Class
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </span>
                </a>
              </Button>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-[#d4a574]/50 text-[#d4a574] hover:bg-[#d4a574]/10 font-semibold text-lg px-10 py-7 rounded-xl group"
                asChild
              >
                <a href="#courses">
                  <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                  Download Course Guide
                </a>
              </Button>
            </motion.div>
          </motion.div>

          {/* Trust Indicators */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 max-w-4xl mx-auto"
          >
            {trustIndicators.map((item, index) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.9 + index * 0.1 }}
                className="group relative"
              >
                <div className="glass-card p-6 rounded-2xl bg-gradient-to-b from-[#1a365d]/50 to-transparent border border-[#d4a574]/10 hover:border-[#d4a574]/30 transition-all duration-300">
                  <div className="flex items-center justify-center mb-3">
                    <div className="w-10 h-10 rounded-lg bg-[#d4a574]/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <item.icon className="w-5 h-5 text-[#d4a574]" />
                    </div>
                  </div>
                  <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
                    <AnimatedCounter target={item.value} suffix={item.suffix} />
                  </div>
                  <p className="text-gray-500 text-sm mt-1">{item.label}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="flex flex-col items-center gap-2 cursor-pointer"
            onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
          >
            <span className="text-gray-500 text-xs uppercase tracking-widest">Scroll</span>
            <div className="w-6 h-10 rounded-full border-2 border-[#d4a574]/30 flex items-start justify-center p-2">
              <motion.div
                animate={{ y: [0, 12, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-1.5 h-1.5 rounded-full bg-[#d4a574]"
              />
            </div>
          </motion.div>
        </motion.div>
      </motion.div>
    </section>
  );
}
