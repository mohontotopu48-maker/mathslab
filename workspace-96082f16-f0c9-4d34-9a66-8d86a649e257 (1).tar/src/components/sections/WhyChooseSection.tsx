'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Globe, Target, Users, BarChart3, Headphones, Award, Shield, Zap, CheckCircle2 } from 'lucide-react';
import GlassCard from '@/components/ui/custom/GlassCard';

const whyChooseItems = [
  { icon: Globe, title: 'International Curriculum Specialist', desc: 'Expert in Cambridge & Edexcel with proven results across 15+ countries' },
  { icon: Target, title: 'Personalized Study Plan', desc: 'Tailored approach based on your unique learning style and goals' },
  { icon: Users, title: 'Small Batch or 1-to-1', desc: 'Individual attention for maximum impact and faster progress' },
  { icon: BarChart3, title: 'Regular Progress Reports', desc: 'Stay updated with detailed performance tracking and insights' },
  { icon: Headphones, title: '24/7 Doubt Support', desc: 'Get your questions answered anytime via WhatsApp or email' },
  { icon: Award, title: 'Proven Track Record', desc: '10+ years of A* results with 95% success rate' },
];

export default function WhyChooseSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[#0a1628]" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#d4a574]/20 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left side - Features */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-[#d4a574]/10 text-[#d4a574] text-sm font-medium mb-4">
              Why Choose Us
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
              Why Choose{' '}
              <span className="bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
                Maths Lab
              </span>
              ?
            </h2>
            <p className="text-gray-400 text-lg mb-10">
              We combine expertise, personalized attention, and proven methods to deliver exceptional results for every student.
            </p>

            <div className="grid sm:grid-cols-2 gap-6">
              {whyChooseItems.map((item, index) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.2 + index * 0.1 }}
                  className="flex items-start gap-4 group"
                >
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#d4a574] to-[#e8c9a0] flex items-center justify-center shadow-lg shadow-[#d4a574]/20 flex-shrink-0"
                  >
                    <item.icon className="w-6 h-6 text-[#0a1628]" />
                  </motion.div>
                  <div>
                    <h4 className="font-semibold text-white mb-1 group-hover:text-[#d4a574] transition-colors">
                      {item.title}
                    </h4>
                    <p className="text-sm text-gray-500">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right side - Guarantee card */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <GlassCard className="p-8 md:p-10" glow>
              <div className="text-center">
                {/* Shield icon */}
                <motion.div
                  whileHover={{ scale: 1.05, rotate: 5 }}
                  className="w-24 h-24 rounded-2xl bg-gradient-to-br from-[#d4a574] to-[#e8c9a0] flex items-center justify-center mx-auto mb-6 shadow-xl shadow-[#d4a574]/30"
                >
                  <Shield className="w-12 h-12 text-[#0a1628]" />
                </motion.div>

                <h3 className="text-2xl font-bold text-white mb-4">Quality Guarantee</h3>
                <p className="text-gray-400 mb-8 leading-relaxed">
                  If you don&apos;t see improvement after 4 weeks of following our program, we&apos;ll provide additional support at no extra cost.
                </p>

                {/* Stats */}
                <div className="flex justify-center gap-8 mb-8">
                  {[
                    { value: '95%', label: 'Success Rate' },
                    { value: '4.9', label: 'Avg Rating' },
                    { value: '24/7', label: 'Support' },
                  ].map((stat) => (
                    <div key={stat.label} className="text-center">
                      <div className="text-3xl font-bold bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
                        {stat.value}
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{stat.label}</p>
                    </div>
                  ))}
                </div>

                {/* Features list */}
                <div className="space-y-3 text-left">
                  {[
                    'Free trial class with no commitment',
                    'Flexible scheduling for all time zones',
                    'Money-back guarantee for first month',
                  ].map((feature, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={isInView ? { opacity: 1, x: 0 } : {}}
                      transition={{ delay: 0.5 + index * 0.1 }}
                      className="flex items-center gap-3"
                    >
                      <CheckCircle2 className="w-5 h-5 text-[#10b981] flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </motion.div>
                  ))}
                </div>

                {/* CTA */}
                <motion.a
                  href="#contact"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="mt-8 w-full inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] text-[#0a1628] font-semibold shadow-lg shadow-[#d4a574]/20"
                >
                  <Zap className="w-5 h-5" />
                  Start Your Free Trial
                </motion.a>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
