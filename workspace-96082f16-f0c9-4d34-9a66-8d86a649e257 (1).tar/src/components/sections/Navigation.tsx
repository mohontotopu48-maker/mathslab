'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { Menu, X, Calculator, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

const navLinks = [
  { href: '#about', label: 'About' },
  { href: '#courses', label: 'Courses' },
  { href: '#methodology', label: 'Methodology' },
  { href: '#results', label: 'Results' },
  { href: '#contact', label: 'Contact' },
];

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { scrollY } = useScroll();

  useEffect(() => {
    const unsubscribe = scrollY.on('change', (y) => {
      setIsScrolled(y > 50);
    });
    return () => unsubscribe();
  }, [scrollY]);

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 100 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-[rgba(10,22,40,0.95)] backdrop-blur-xl border-b border-[#d4a574]/10 shadow-lg shadow-black/20' 
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <motion.a
              href="#"
              className="flex items-center gap-3 group"
              whileHover={{ scale: 1.02 }}
            >
              <motion.div
                whileHover={{ rotate: 10 }}
                className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#d4a574] to-[#e8c9a0] flex items-center justify-center shadow-lg shadow-[#d4a574]/20"
              >
                <Calculator className="w-6 h-6 text-[#0a1628]" />
              </motion.div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-white">Maths Lab</span>
                <span className="text-[10px] text-[#d4a574] tracking-widest uppercase">Excellence in Mathematics</span>
              </div>
            </motion.a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link, index) => (
                <motion.a
                  key={link.href}
                  href={link.href}
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="relative text-gray-300 hover:text-[#d4a574] transition-colors py-2 group"
                >
                  {link.label}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] group-hover:w-full transition-all duration-300" />
                </motion.a>
              ))}
            </div>

            {/* CTA Button */}
            <div className="hidden lg:block">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 }}
              >
                <Button
                  className="bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] text-[#0a1628] font-semibold px-6 py-5 hover:shadow-lg hover:shadow-[#d4a574]/30 transition-all duration-300 relative overflow-hidden group"
                  asChild
                >
                  <a href="#contact">
                    <span className="relative z-10 flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      Book Free Trial
                    </span>
                  </a>
                </Button>
              </motion.div>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="lg:hidden w-12 h-12 rounded-xl bg-[#1a365d] flex items-center justify-center text-white hover:bg-[#1e3a5f] transition-colors"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed top-20 left-0 right-0 z-40 lg:hidden bg-[rgba(10,22,40,0.98)] backdrop-blur-xl border-b border-[#d4a574]/10"
          >
            <div className="max-w-7xl mx-auto px-4 py-6">
              <div className="flex flex-col gap-4">
                {navLinks.map((link, index) => (
                  <motion.a
                    key={link.href}
                    href={link.href}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => setIsOpen(false)}
                    className="text-gray-300 hover:text-[#d4a574] transition-colors py-3 px-4 rounded-lg hover:bg-[#1a365d]/50"
                  >
                    {link.label}
                  </motion.a>
                ))}
                <Button
                  className="mt-4 bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] text-[#0a1628] font-semibold py-6"
                  asChild
                >
                  <a href="#contact" onClick={() => setIsOpen(false)}>
                    <Phone className="w-4 h-4 mr-2" />
                    Book Free Trial
                  </a>
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
