'use client';

import { motion, useInView } from 'framer-motion';
import { useRef, useState, useEffect } from 'react';
import { Star, ArrowLeft, ArrowRight, Quote, TrendingUp } from 'lucide-react';
import GlassCard from '@/components/ui/custom/GlassCard';

const testimonials = [
  {
    name: 'Sarah Ahmed',
    role: 'A Level Student',
    location: 'UK',
    text: 'The personalized approach made all the difference. I went from struggling with calculus to achieving an A* in my A Levels! The teaching methodology is exceptional.',
    rating: 5,
    improvement: 'C → A*',
    subject: 'A Level Mathematics',
  },
  {
    name: 'Muhammad Ali',
    role: 'O Level Student',
    location: 'UAE',
    text: 'Amazing teaching methodology! The concepts that seemed impossible became so clear. The practice sessions and mock tests really prepared me well.',
    rating: 5,
    improvement: 'D → A',
    subject: 'O Level Mathematics',
  },
  {
    name: 'Zara Khan',
    role: 'Parent',
    location: 'Singapore',
    text: 'As a parent, I appreciate the regular progress updates and the dedication to my daughter\'s success. She improved significantly in just 3 months.',
    rating: 5,
    improvement: 'E → B',
    subject: 'O Level Mathematics',
  },
  {
    name: 'David Chen',
    role: 'A Level Student',
    location: 'Malaysia',
    text: 'The statistics module was my biggest challenge, but with the structured approach and patient guidance, I scored an A. Highly recommended!',
    rating: 5,
    improvement: 'D → A',
    subject: 'A Level Statistics',
  },
  {
    name: 'Fatima Rahman',
    role: 'AS Level Student',
    location: 'Bangladesh',
    text: 'Excellent tutor who really understands the Cambridge curriculum. The exam techniques taught here are invaluable. Got A in both Pure Math and Statistics!',
    rating: 5,
    improvement: 'C → A',
    subject: 'AS Level Mathematics',
  },
];

const gradeImprovements = [
  { before: 'D', after: 'B', label: 'Most Common', percentage: 45 },
  { before: 'C', after: 'A', label: 'Typical', percentage: 35 },
  { before: 'B', after: 'A*', label: 'High Achievers', percentage: 20 },
];

export default function ResultsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [animatedPercentages, setAnimatedPercentages] = useState([0, 0, 0]);

  useEffect(() => {
    if (isInView) {
      const timer = setTimeout(() => {
        setAnimatedPercentages(gradeImprovements.map(g => g.percentage));
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isInView]);

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="results" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[#0a1628]" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#d4a574]/20 to-transparent" />

      {/* Decorative elements */}
      <div className="absolute top-1/3 -right-32 w-64 h-64 bg-[#10b981]/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-[#d4a574]/10 text-[#d4a574] text-sm font-medium mb-4">
            Results & Testimonials
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Proven Track Record of{' '}
            <span className="bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
              Academic Excellence
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Real results from real students. See how we transform grades.
          </p>
        </motion.div>

        {/* Grade Improvement Chart */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <GlassCard className="p-8">
            <div className="flex items-center gap-3 mb-8">
              <TrendingUp className="w-6 h-6 text-[#d4a574]" />
              <h3 className="text-xl font-semibold text-white">Average Grade Improvement</h3>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {gradeImprovements.map((item, index) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className="text-center"
                >
                  <div className="flex items-center justify-center gap-4 mb-4">
                    <div className="w-16 h-16 rounded-xl bg-red-500/20 flex items-center justify-center text-2xl font-bold text-red-400 border border-red-500/30">
                      {item.before}
                    </div>
                    <ArrowRight className="w-6 h-6 text-gray-500" />
                    <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#10b981] to-[#059669] flex items-center justify-center text-2xl font-bold text-white shadow-lg shadow-green-500/20">
                      {item.after}
                    </div>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="w-full h-2 bg-[#1a365d] rounded-full overflow-hidden mb-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${animatedPercentages[index]}%` }}
                      transition={{ duration: 1, delay: 0.5 + index * 0.1 }}
                      className="h-full bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] rounded-full"
                    />
                  </div>
                  
                  <span className="text-sm text-gray-500">{item.label} ({item.percentage}%)</span>
                </motion.div>
              ))}
            </div>
          </GlassCard>
        </motion.div>

        {/* Testimonials Carousel */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.4 }}
        >
          <GlassCard className="p-8 md:p-12 relative">
            <Quote className="absolute top-6 left-6 w-12 h-12 text-[#d4a574]/10" />
            
            <div className="relative">
              {/* Testimonial Content */}
              <div className="min-h-[200px] flex items-center justify-center mb-8">
                <motion.div
                  key={currentTestimonial}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3 }}
                  className="text-center max-w-3xl mx-auto"
                >
                  {/* Stars */}
                  <div className="flex justify-center gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <motion.div
                        key={i}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: i * 0.05 }}
                      >
                        <Star className={`w-5 h-5 ${i < testimonials[currentTestimonial].rating ? 'text-[#d4a574] fill-[#d4a574]' : 'text-gray-600'}`} />
                      </motion.div>
                    ))}
                  </div>

                  {/* Text */}
                  <p className="text-xl md:text-2xl text-gray-300 mb-6 italic leading-relaxed">
                    &ldquo;{testimonials[currentTestimonial].text}&rdquo;
                  </p>

                  {/* Author */}
                  <div className="flex items-center justify-center gap-6">
                    <div className="text-right">
                      <p className="font-semibold text-white">{testimonials[currentTestimonial].name}</p>
                      <p className="text-sm text-gray-500">{testimonials[currentTestimonial].role} • {testimonials[currentTestimonial].location}</p>
                    </div>
                    <div className="w-px h-10 bg-[#d4a574]/20" />
                    <div className="text-left">
                      <p className="text-sm text-gray-500">Grade Improvement</p>
                      <p className="text-lg font-bold bg-gradient-to-r from-[#10b981] to-[#059669] bg-clip-text text-transparent">
                        {testimonials[currentTestimonial].improvement}
                      </p>
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={prevTestimonial}
                  className="w-12 h-12 rounded-xl bg-[#1a365d] flex items-center justify-center text-gray-400 hover:bg-[#d4a574]/20 hover:text-[#d4a574] transition-all"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>

                <div className="flex gap-2">
                  {testimonials.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentTestimonial(index)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentTestimonial 
                          ? 'w-8 bg-gradient-to-r from-[#d4a574] to-[#e8c9a0]' 
                          : 'bg-[#d4a574]/30 hover:bg-[#d4a574]/50'
                      }`}
                    />
                  ))}
                </div>

                <button
                  onClick={nextTestimonial}
                  className="w-12 h-12 rounded-xl bg-[#1a365d] flex items-center justify-center text-gray-400 hover:bg-[#d4a574]/20 hover:text-[#d4a574] transition-all"
                >
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
          {[
            { value: '1000+', label: 'Students Taught' },
            { value: '95%', label: 'A-A* Rate' },
            { value: '4.9/5', label: 'Average Rating' },
            { value: '15+', label: 'Countries' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.6 + index * 0.1 }}
              className="text-center p-6 rounded-xl bg-[#1a365d]/30 border border-[#d4a574]/10"
            >
              <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
                {stat.value}
              </div>
              <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
