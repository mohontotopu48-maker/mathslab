'use client';

import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { Calculator, TrendingUp, Award, CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import GlassCard from '@/components/ui/custom/GlassCard';

const courses = [
  {
    id: 'olevel',
    title: 'O Level Mathematics',
    subtitle: 'Foundation Excellence',
    description: 'Complete syllabus coverage with exam-focused preparation',
    icon: Calculator,
    color: 'from-[#d4a574] to-[#b8956a]',
    features: [
      'Complete Cambridge/Edexcel syllabus coverage',
      'Weekly practice sessions & mock tests',
      'Past paper analysis & exam techniques',
      'Small batch or personalized 1-to-1',
      'Regular progress tracking & feedback',
    ],
    gradient: 'from-[#d4a574]/20 to-transparent',
    popular: false,
  },
  {
    id: 'alevel',
    title: 'A Level Mathematics',
    subtitle: 'Advanced Mastery',
    description: 'Pure Math, Mechanics & Statistics modules',
    icon: TrendingUp,
    color: 'from-[#10b981] to-[#059669]',
    features: [
      'Pure Mathematics (P1, P2, P3, P4)',
      'Mechanics (M1, M2)',
      'Statistics (S1, S2)',
      'Step-by-step problem solving',
      'Exam strategy & time management',
    ],
    gradient: 'from-[#10b981]/20 to-transparent',
    popular: true,
  },
  {
    id: 'further',
    title: 'A Level Further Maths',
    subtitle: 'Elite Performance',
    description: 'Advanced topics for ambitious students',
    icon: Award,
    color: 'from-[#3b82f6] to-[#2563eb]',
    features: [
      'Further Pure Mathematics',
      'Further Mechanics & Statistics',
      'Olympiad preparation',
      'University entrance support',
      'Competition-level problem solving',
    ],
    gradient: 'from-[#3b82f6]/20 to-transparent',
    popular: false,
  },
];

export default function CoursesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  return (
    <section id="courses" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[#0a1628]" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#d4a574]/20 to-transparent" />
      
      {/* Decorative elements */}
      <div className="absolute top-1/4 -left-32 w-64 h-64 bg-[#d4a574]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-64 h-64 bg-[#3b82f6]/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-[#d4a574]/10 text-[#d4a574] text-sm font-medium mb-4">
            Our Courses
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Comprehensive{' '}
            <span className="bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
              Course Offerings
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            From O Level to A Level Further Mathematics, we cover everything you need to excel
          </p>
        </motion.div>

        {/* Course Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              onMouseEnter={() => setHoveredCard(course.id)}
              onMouseLeave={() => setHoveredCard(null)}
              className="relative group perspective-1000"
            >
              {/* Popular badge */}
              {course.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20">
                  <span className="inline-flex items-center gap-1 px-4 py-1 rounded-full bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] text-[#0a1628] text-xs font-bold shadow-lg">
                    <Sparkles className="w-3 h-3" />
                    Most Popular
                  </span>
                </div>
              )}

              <motion.div
                animate={{ 
                  rotateY: hoveredCard === course.id ? 180 : 0,
                  scale: hoveredCard === course.id ? 1.02 : 1
                }}
                transition={{ duration: 0.6, type: "spring", stiffness: 100 }}
                className="relative w-full min-h-[420px] preserve-3d cursor-pointer"
              >
                {/* Front Face */}
                <div className="absolute inset-0 backface-hidden">
                  <GlassCard 
                    className={`h-full p-8 flex flex-col bg-gradient-to-b ${course.gradient}`}
                    glow={hoveredCard === course.id}
                  >
                    {/* Icon */}
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${course.color} flex items-center justify-center shadow-lg mb-6`}>
                      <course.icon className="w-8 h-8 text-white" />
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <span className="text-xs text-[#d4a574] font-medium uppercase tracking-wider">
                        {course.subtitle}
                      </span>
                      <h3 className="text-xl font-bold text-white mt-1 mb-3">{course.title}</h3>
                      <p className="text-gray-400">{course.description}</p>
                    </div>

                    {/* Hover hint */}
                    <div className="mt-6 pt-6 border-t border-[#d4a574]/10">
                      <p className="text-sm text-[#d4a574] flex items-center gap-2 group-hover:gap-3 transition-all">
                        <span>View Details</span>
                        <ArrowRight className="w-4 h-4" />
                      </p>
                    </div>
                  </GlassCard>
                </div>

                {/* Back Face */}
                <div 
                  className="absolute inset-0 backface-hidden"
                  style={{ transform: 'rotateY(180deg)' }}
                >
                  <GlassCard className="h-full p-8 flex flex-col bg-gradient-to-b from-[#1a365d]/50 to-[#0f2847]">
                    <h3 className="text-lg font-bold text-[#d4a574] mb-4">Course Highlights</h3>
                    
                    <ul className="flex-1 space-y-3">
                      {course.features.map((feature, i) => (
                        <motion.li
                          key={i}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: hoveredCard === course.id ? 1 : 0, x: hoveredCard === course.id ? 0 : -10 }}
                          transition={{ delay: i * 0.05 }}
                          className="flex items-start gap-3 text-gray-300"
                        >
                          <CheckCircle2 className={`w-5 h-5 mt-0.5 flex-shrink-0 bg-gradient-to-br ${course.color} text-white rounded-full`} style={{ padding: '2px' }} />
                          <span className="text-sm">{feature}</span>
                        </motion.li>
                      ))}
                    </ul>

                    <Button 
                      className={`mt-6 bg-gradient-to-r ${course.color} text-white font-semibold py-6 rounded-xl hover:shadow-lg transition-all`}
                      asChild
                    >
                      <a href="#contact">Enroll Now</a>
                    </Button>
                  </GlassCard>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8 }}
          className="mt-16 text-center"
        >
          <p className="text-gray-500 mb-4">Not sure which course is right for you?</p>
          <Button
            variant="outline"
            className="border-[#d4a574]/50 text-[#d4a574] hover:bg-[#d4a574]/10 px-8 py-6 rounded-xl"
            asChild
          >
            <a href="#contact">Get Free Consultation</a>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
