'use client';

import { motion } from 'framer-motion';
import { Calculator, Phone, Mail, MessageCircle, MapPin, Heart } from 'lucide-react';

const footerLinks = {
  courses: [
    { label: 'O Level Mathematics', href: '#courses' },
    { label: 'A Level Mathematics', href: '#courses' },
    { label: 'A Level Further Maths', href: '#courses' },
    { label: 'Statistics', href: '#courses' },
  ],
  company: [
    { label: 'About', href: '#about' },
    { label: 'Methodology', href: '#methodology' },
    { label: 'Results', href: '#results' },
    { label: 'Contact', href: '#contact' },
  ],
  support: [
    { label: 'Book Trial', href: '#contact' },
    { label: 'FAQ', href: '#' },
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms of Service', href: '#' },
  ],
};

export default function Footer() {
  return (
    <footer className="relative bg-[#050d1a] border-t border-[#d4a574]/10">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <motion.a
              href="#"
              className="flex items-center gap-3 mb-6 group"
              whileHover={{ scale: 1.02 }}
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#d4a574] to-[#e8c9a0] flex items-center justify-center shadow-lg shadow-[#d4a574]/20">
                <Calculator className="w-6 h-6 text-[#0a1628]" />
              </div>
              <div>
                <span className="text-xl font-bold text-white">Maths Lab</span>
                <p className="text-[10px] text-[#d4a574] tracking-widest uppercase">Excellence in Mathematics</p>
              </div>
            </motion.a>

            <p className="text-gray-500 mb-6 max-w-sm">
              Transforming students into confident mathematicians through personalized online tutoring for O & A Level Cambridge and Edexcel curricula.
            </p>

            {/* Contact */}
            <div className="space-y-3">
              <a href="#" className="flex items-center gap-3 text-gray-400 hover:text-[#d4a574] transition-colors">
                <Phone className="w-4 h-4" />
                <span>+44 123 456 7890</span>
              </a>
              <a href="#" className="flex items-center gap-3 text-gray-400 hover:text-[#d4a574] transition-colors">
                <Mail className="w-4 h-4" />
                <span>hello@mathslab.com</span>
              </a>
              <a href="#" className="flex items-center gap-3 text-gray-400 hover:text-[#d4a574] transition-colors">
                <MapPin className="w-4 h-4" />
                <span>Online Classes Worldwide</span>
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold text-white mb-4">Courses</h4>
            <ul className="space-y-3">
              {footerLinks.courses.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-gray-500 hover:text-[#d4a574] transition-colors text-sm">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-gray-500 hover:text-[#d4a574] transition-colors text-sm">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Support</h4>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-gray-500 hover:text-[#d4a574] transition-colors text-sm">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-[#d4a574]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm flex items-center gap-1">
              © {new Date().getFullYear()} Maths Lab. Made with <Heart className="w-4 h-4 text-red-500 fill-red-500" /> for students worldwide.
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-4">
              {[
                { icon: MessageCircle, label: 'WhatsApp' },
                { icon: Mail, label: 'Email' },
              ].map((social) => (
                <motion.a
                  key={social.label}
                  href="#"
                  whileHover={{ scale: 1.1, y: -2 }}
                  className="w-10 h-10 rounded-lg bg-[#1a365d] flex items-center justify-center text-gray-400 hover:text-[#d4a574] hover:bg-[#1a365d]/80 transition-all"
                >
                  <social.icon className="w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
