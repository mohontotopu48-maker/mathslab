'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Globe, Play, Clock, BookOpen, FileCheck, Video } from 'lucide-react';
import GlassCard from '@/components/ui/custom/GlassCard';

const countries = [
  { name: 'UK', x: '42%', y: '22%' },
  { name: 'UAE', x: '58%', y: '40%' },
  { name: 'Malaysia', x: '75%', y: '55%' },
  { name: 'Singapore', x: '77%', y: '58%' },
  { name: 'Canada', x: '18%', y: '20%' },
  { name: 'Bangladesh', x: '68%', y: '38%' },
];

const features = [
  { icon: Video, title: 'Live Zoom Classes', desc: 'Interactive sessions with real-time Q&A' },
  { icon: Clock, title: 'Recorded Lessons', desc: 'Access lessons anytime, anywhere' },
  { icon: BookOpen, title: 'Digital Whiteboard', desc: 'Visual learning with advanced tools' },
  { icon: FileCheck, title: 'Assignment Support', desc: 'Detailed feedback on all work' },
];

export default function InternationalSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a1628] via-[#0f2847]/20 to-[#0a1628]" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#d4a574]/20 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-[#d4a574]/10 text-[#d4a574] text-sm font-medium mb-4">
            Global Reach
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Serving Students{' '}
            <span className="bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
              Globally
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Flexible time zones to accommodate students from around the world
          </p>
        </motion.div>

        {/* World Map */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8 }}
          className="relative h-64 md:h-96 mb-16"
        >
          <GlassCard className="h-full p-8">
            {/* Map background */}
            <div className="absolute inset-0 opacity-10">
              <svg viewBox="0 0 800 400" className="w-full h-full">
                {/* Simplified world map paths */}
                <path
                  d="M100,100 Q150,80 200,90 Q250,70 300,85 Q350,65 400,80 Q450,60 500,75 Q550,70 600,85 Q650,75 700,90 L720,140 Q680,170 630,160 Q580,180 530,165 Q480,185 430,170 Q380,195 330,175 Q280,200 230,180 Q180,210 130,185 Q80,200 70,160 Q60,130 100,100"
                  fill="none"
                  stroke="#d4a574"
                  strokeWidth="1.5"
                />
                <path
                  d="M150,200 Q200,230 250,220 Q300,250 350,235 Q400,260 450,245 Q500,270 550,255 Q600,280 650,265"
                  fill="none"
                  stroke="#d4a574"
                  strokeWidth="1.5"
                />
                <path
                  d="M580,150 Q630,180 680,170 Q730,200 750,180 Q770,220 740,250 Q700,280 650,270"
                  fill="none"
                  stroke="#d4a574"
                  strokeWidth="1.5"
                />
                <path
                  d="M200,300 Q250,320 300,310 Q350,340 400,325 Q450,350 500,335 Q550,360 600,345"
                  fill="none"
                  stroke="#d4a574"
                  strokeWidth="1.5"
                />
              </svg>
            </div>

            {/* Country dots */}
            {countries.map((country, index) => (
              <motion.div
                key={country.name}
                initial={{ scale: 0, opacity: 0 }}
                animate={isInView ? { scale: 1, opacity: 1 } : {}}
                transition={{ delay: 0.3 + index * 0.1, type: "spring", stiffness: 200 }}
                className="absolute group cursor-pointer"
                style={{ left: country.x, top: country.y }}
              >
                {/* Pulse rings */}
                <div className="absolute inset-0 -m-2">
                  <div className="absolute inset-0 rounded-full bg-[#d4a574]/20 animate-ping" />
                  <div className="absolute inset-0 rounded-full bg-[#d4a574]/10 animate-pulse" />
                </div>
                
                {/* Dot */}
                <div className="relative w-4 h-4 rounded-full bg-gradient-to-br from-[#d4a574] to-[#e8c9a0] shadow-lg shadow-[#d4a574]/30 group-hover:scale-150 transition-transform" />
                
                {/* Label */}
                <div className="absolute left-6 -top-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="px-3 py-1 rounded-lg bg-[#1a365d] text-[#d4a574] text-sm font-medium whitespace-nowrap shadow-lg">
                    {country.name}
                  </span>
                </div>
              </motion.div>
            ))}

            {/* Center text */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 1 }}
                className="text-center"
              >
                <Globe className="w-12 h-12 text-[#d4a574]/30 mx-auto mb-2" />
                <p className="text-gray-500 text-sm">Hover over locations to see countries</p>
              </motion.div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.5 + index * 0.1 }}
            >
              <GlassCard className="p-6 text-center h-full group hover:bg-[#1a365d]/50">
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#d4a574] to-[#e8c9a0] flex items-center justify-center mx-auto mb-4 shadow-lg shadow-[#d4a574]/20"
                >
                  <feature.icon className="w-7 h-7 text-[#0a1628]" />
                </motion.div>
                <h3 className="font-semibold text-white mb-2 group-hover:text-[#d4a574] transition-colors">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-500">{feature.desc}</p>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
