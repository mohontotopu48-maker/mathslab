'use client';

import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { Zap, ArrowRight, CheckCircle2, Phone, Mail, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import GlassCard from '@/components/ui/custom/GlassCard';

const countries = [
  'United Kingdom', 'United Arab Emirates', 'Malaysia', 'Singapore', 
  'Canada', 'Bangladesh', 'Pakistan', 'India', 'USA', 'Australia', 'Other'
];

const curriculums = ['Cambridge (CAIE)', 'Edexcel', 'Both / Not Sure'];
const levels = ['O Level', 'AS Level', 'A2 Level', 'Full A Level', 'Other'];
const grades = ['A*', 'A', 'B', 'C', 'D', 'E or below', 'Not sure'];

export default function LeadFormSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    studentName: '',
    country: '',
    curriculum: '',
    level: '',
    currentGrade: '',
    targetGrade: '',
    whatsapp: '',
    email: '',
    message: ''
  });
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: "Success! 🎉",
          description: data.message,
        });
        setFormData({
          studentName: '',
          country: '',
          curriculum: '',
          level: '',
          currentGrade: '',
          targetGrade: '',
          whatsapp: '',
          email: '',
          message: ''
        });
      } else {
        toast({
          title: "Error",
          description: data.error,
          variant: "destructive"
        });
      }
    } catch {
      toast({
        title: "Error",
        description: "Failed to submit form. Please try again.",
        variant: "destructive"
      });
    }

    setIsSubmitting(false);
  };

  return (
    <section id="contact" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a1628] via-[#0f2847]/30 to-[#0a1628]" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#d4a574]/20 to-transparent" />

      {/* Decorative elements */}
      <div className="absolute top-1/4 -left-32 w-64 h-64 bg-[#d4a574]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-64 h-64 bg-[#d4a574]/5 rounded-full blur-3xl" />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={isInView ? { scale: 1 } : {}}
            transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#d4a574]/20 to-[#e8c9a0]/10 border border-[#d4a574]/20 mb-6"
          >
            <Zap className="w-4 h-4 text-[#d4a574]" />
            <span className="text-sm text-[#d4a574] font-medium">Limited Slots Available</span>
          </motion.div>

          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Book Your{' '}
            <span className="bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent">
              Free Trial Class
            </span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Response within 24 hours • No commitment required • See the difference
          </p>
        </motion.div>

        {/* Form */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <GlassCard className="p-6 md:p-10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Student Name */}
                <div className="space-y-2">
                  <Label htmlFor="studentName" className="text-white flex items-center gap-2">
                    Student Name <span className="text-red-400">*</span>
                  </Label>
                  <Input
                    id="studentName"
                    value={formData.studentName}
                    onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                    placeholder="Enter student's full name"
                    required
                    className="h-12 bg-[#0f2847] border-[#d4a574]/20 text-white placeholder:text-gray-500 focus:border-[#d4a574] focus:ring-[#d4a574]/20 rounded-xl"
                  />
                </div>

                {/* Country */}
                <div className="space-y-2">
                  <Label htmlFor="country" className="text-white flex items-center gap-2">
                    Country <span className="text-red-400">*</span>
                  </Label>
                  <Select value={formData.country} onValueChange={(value) => setFormData({ ...formData, country: value })}>
                    <SelectTrigger className="h-12 bg-[#0f2847] border-[#d4a574]/20 text-white rounded-xl">
                      <SelectValue placeholder="Select your country" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0f2847] border-[#d4a574]/20">
                      {countries.map((country) => (
                        <SelectItem key={country} value={country} className="text-white hover:bg-[#1a365d]">
                          {country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Curriculum */}
                <div className="space-y-2">
                  <Label htmlFor="curriculum" className="text-white flex items-center gap-2">
                    Curriculum <span className="text-red-400">*</span>
                  </Label>
                  <Select value={formData.curriculum} onValueChange={(value) => setFormData({ ...formData, curriculum: value })}>
                    <SelectTrigger className="h-12 bg-[#0f2847] border-[#d4a574]/20 text-white rounded-xl">
                      <SelectValue placeholder="Select curriculum" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0f2847] border-[#d4a574]/20">
                      {curriculums.map((curriculum) => (
                        <SelectItem key={curriculum} value={curriculum} className="text-white hover:bg-[#1a365d]">
                          {curriculum}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Level */}
                <div className="space-y-2">
                  <Label htmlFor="level" className="text-white flex items-center gap-2">
                    Level <span className="text-red-400">*</span>
                  </Label>
                  <Select value={formData.level} onValueChange={(value) => setFormData({ ...formData, level: value })}>
                    <SelectTrigger className="h-12 bg-[#0f2847] border-[#d4a574]/20 text-white rounded-xl">
                      <SelectValue placeholder="Select level" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0f2847] border-[#d4a574]/20">
                      {levels.map((level) => (
                        <SelectItem key={level} value={level} className="text-white hover:bg-[#1a365d]">
                          {level}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Current Grade */}
                <div className="space-y-2">
                  <Label htmlFor="currentGrade" className="text-white">Current Grade</Label>
                  <Select value={formData.currentGrade} onValueChange={(value) => setFormData({ ...formData, currentGrade: value })}>
                    <SelectTrigger className="h-12 bg-[#0f2847] border-[#d4a574]/20 text-white rounded-xl">
                      <SelectValue placeholder="Select current grade" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0f2847] border-[#d4a574]/20">
                      {grades.map((grade) => (
                        <SelectItem key={grade} value={grade} className="text-white hover:bg-[#1a365d]">
                          {grade}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Target Grade */}
                <div className="space-y-2">
                  <Label htmlFor="targetGrade" className="text-white">Target Grade</Label>
                  <Select value={formData.targetGrade} onValueChange={(value) => setFormData({ ...formData, targetGrade: value })}>
                    <SelectTrigger className="h-12 bg-[#0f2847] border-[#d4a574]/20 text-white rounded-xl">
                      <SelectValue placeholder="Select target grade" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0f2847] border-[#d4a574]/20">
                      {grades.slice(0, 4).map((grade) => (
                        <SelectItem key={grade} value={grade} className="text-white hover:bg-[#1a365d]">
                          {grade}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* WhatsApp */}
                <div className="space-y-2">
                  <Label htmlFor="whatsapp" className="text-white flex items-center gap-2">
                    WhatsApp Number <span className="text-red-400">*</span>
                  </Label>
                  <Input
                    id="whatsapp"
                    type="tel"
                    value={formData.whatsapp}
                    onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                    placeholder="+44 123 456 7890"
                    required
                    className="h-12 bg-[#0f2847] border-[#d4a574]/20 text-white placeholder:text-gray-500 focus:border-[#d4a574] focus:ring-[#d4a574]/20 rounded-xl"
                  />
                </div>

                {/* Email */}
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white flex items-center gap-2">
                    Email <span className="text-red-400">*</span>
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="student@email.com"
                    required
                    className="h-12 bg-[#0f2847] border-[#d4a574]/20 text-white placeholder:text-gray-500 focus:border-[#d4a574] focus:ring-[#d4a574]/20 rounded-xl"
                  />
                </div>
              </div>

              {/* Message */}
              <div className="space-y-2">
                <Label htmlFor="message" className="text-white">Additional Message (Optional)</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell us about your specific needs, goals, or any questions you have..."
                  rows={4}
                  className="bg-[#0f2847] border-[#d4a574]/20 text-white placeholder:text-gray-500 focus:border-[#d4a574] focus:ring-[#d4a574]/20 rounded-xl resize-none"
                />
              </div>

              {/* Benefits */}
              <div className="grid sm:grid-cols-3 gap-4 py-4">
                {[
                  'Free 30-minute trial class',
                  'No credit card required',
                  'Response within 24 hours'
                ].map((benefit, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    className="flex items-center gap-2 text-gray-400"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#10b981]" />
                    <span className="text-sm">{benefit}</span>
                  </motion.div>
                ))}
              </div>

              {/* Submit Button */}
              <div className="text-center pt-4">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full md:w-auto bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] text-[#0a1628] font-bold text-lg px-12 py-7 rounded-xl hover:shadow-xl hover:shadow-[#d4a574]/30 transition-all duration-300 disabled:opacity-50 group"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-[#0a1628]/30 border-t-[#0a1628] rounded-full animate-spin" />
                      Submitting...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      Book Free Trial Class
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </span>
                  )}
                </Button>
                <p className="text-gray-500 text-sm mt-4">
                  By submitting, you agree to be contacted about our tutoring services.
                </p>
              </div>
            </form>
          </GlassCard>
        </motion.div>

        {/* Contact Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6 }}
          className="mt-12 flex flex-wrap justify-center gap-8"
        >
          {[
            { icon: Phone, label: 'Call Us', value: '+44 123 456 7890' },
            { icon: Mail, label: 'Email', value: 'hello@mathslab.com' },
            { icon: MessageCircle, label: 'WhatsApp', value: '+44 123 456 7890' },
          ].map((contact, index) => (
            <motion.a
              key={contact.label}
              href="#"
              whileHover={{ scale: 1.05 }}
              className="flex items-center gap-3 text-gray-400 hover:text-[#d4a574] transition-colors"
            >
              <div className="w-10 h-10 rounded-lg bg-[#1a365d] flex items-center justify-center">
                <contact.icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-gray-500">{contact.label}</p>
                <p className="font-medium">{contact.value}</p>
              </div>
            </motion.a>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
