'use client';

import { motion } from 'framer-motion';

const mathElements = [
  { symbol: '∫', x: '8%', y: '15%', size: 'text-3xl md:text-4xl', duration: 6 },
  { symbol: 'Σ', x: '88%', y: '12%', size: 'text-4xl md:text-5xl', duration: 7 },
  { symbol: 'π', x: '78%', y: '75%', size: 'text-3xl md:text-4xl', duration: 5.5 },
  { symbol: '√', x: '15%', y: '85%', size: 'text-4xl md:text-5xl', duration: 6.5 },
  { symbol: '∞', x: '92%', y: '45%', size: 'text-3xl md:text-4xl', duration: 8 },
  { symbol: 'Δ', x: '5%', y: '55%', size: 'text-4xl md:text-5xl', duration: 7.5 },
  { symbol: 'θ', x: '65%', y: '8%', size: 'text-3xl md:text-4xl', duration: 5 },
  { symbol: 'λ', x: '35%', y: '90%', size: 'text-3xl md:text-4xl', duration: 6.8 },
  { symbol: '∂', x: '25%', y: '35%', size: 'text-4xl md:text-5xl', duration: 7.2 },
  { symbol: 'f(x)', x: '72%', y: '25%', size: 'text-2xl md:text-3xl', duration: 5.8 },
  { symbol: 'dx', x: '45%', y: '80%', size: 'text-2xl md:text-3xl', duration: 6.2 },
  { symbol: 'x²', x: '55%', y: '55%', size: 'text-2xl md:text-3xl', duration: 7.8 },
];

export default function FloatingMath() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none select-none">
      {mathElements.map((el, index) => (
        <motion.div
          key={index}
          className={`absolute ${el.size} font-bold text-[#d4a574]/[0.08]`}
          style={{ 
            left: el.x, 
            top: el.y,
          }}
          animate={{
            y: [-15, 15, -15],
            x: [-5, 5, -5],
            rotate: [-3, 3, -3],
          }}
          transition={{
            duration: el.duration,
            repeat: Infinity,
            ease: "easeInOut",
            delay: index * 0.3,
          }}
        >
          {el.symbol}
        </motion.div>
      ))}
    </div>
  );
}
