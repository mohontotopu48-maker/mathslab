'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { Calculator, Sigma, Pi, SquareRadical, Infinity as InfinityIcon } from 'lucide-react';
import { LucideIcon } from 'lucide-react';

interface LoadingScreenProps {
  isLoading: boolean;
}

const mathSymbols: { Icon: LucideIcon; delay: number }[] = [
  { Icon: Sigma, delay: 0 },
  { Icon: Pi, delay: 0.1 },
  { Icon: Calculator, delay: 0.2 },
  { Icon: SquareRadical, delay: 0.3 },
  { Icon: InfinityIcon, delay: 0.4 },
];

export default function LoadingScreen({ isLoading }: LoadingScreenProps) {
  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-[100] bg-[#0a1628] flex flex-col items-center justify-center"
        >
          {/* Background effects */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#d4a574]/10 rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#1a365d]/50 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
          </div>

          {/* Animated math symbols */}
          <div className="relative flex items-center gap-4 mb-8">
            {mathSymbols.map(({ Icon, delay }, index) => (
              <motion.div
                key={index}
                initial={{ scale: 0, rotate: -180, opacity: 0 }}
                animate={{ 
                  scale: [0, 1.2, 1],
                  rotate: [-180, 0],
                  opacity: 1
                }}
                transition={{ 
                  duration: 0.6,
                  delay: delay,
                  ease: "easeOut"
                }}
                className="w-12 h-12 md:w-16 md:h-16 rounded-xl bg-gradient-to-br from-[#d4a574] to-[#e8c9a0] flex items-center justify-center shadow-lg shadow-[#d4a574]/20"
              >
                <Icon className="w-6 h-6 md:w-8 md:h-8 text-[#0a1628]" />
              </motion.div>
            ))}
          </div>

          {/* Logo text */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="relative"
          >
            <h1 className="text-4xl md:text-5xl font-bold">
              <span className="text-white">Maths</span>
              <span className="bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent"> Lab</span>
            </h1>
          </motion.div>

          {/* Loading bar */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="mt-8 w-48 h-1 bg-[#1a365d] rounded-full overflow-hidden"
          >
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: '100%' }}
              transition={{ 
                duration: 1.5,
                repeat: Infinity,
                ease: "linear"
              }}
              className="h-full w-1/2 bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] rounded-full"
            />
          </motion.div>

          {/* Loading text */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="mt-4 text-gray-500 text-sm"
          >
            Preparing your learning experience...
          </motion.p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
