'use client';

import { motion } from 'framer-motion';

export default function SectionLoader() {
  return (
    <div className="space-y-6 p-6">
      {/* Header skeleton */}
      <div className="text-center space-y-4">
        <motion.div
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="h-10 w-64 mx-auto rounded-lg bg-[#1a365d]"
        />
        <motion.div
          animate={{ opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 1.5, repeat: Infinity, delay: 0.2 }}
          className="h-6 w-96 mx-auto rounded-lg bg-[#1a365d]"
        />
      </div>

      {/* Cards skeleton */}
      <div className="grid md:grid-cols-3 gap-6 mt-8">
        {[1, 2, 3].map((i) => (
          <motion.div
            key={i}
            animate={{ opacity: [0.3, 0.5, 0.3] }}
            transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.1 }}
            className="h-80 rounded-2xl bg-[#1a365d]"
          />
        ))}
      </div>
    </div>
  );
}
