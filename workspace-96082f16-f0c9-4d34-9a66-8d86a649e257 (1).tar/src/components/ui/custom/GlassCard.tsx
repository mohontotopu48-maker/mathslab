'use client';

import { motion } from 'framer-motion';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
}

export default function GlassCard({ 
  children, 
  className = '',
  hover = true,
  glow = false
}: GlassCardProps) {
  return (
    <motion.div
      whileHover={hover ? { 
        scale: 1.02,
        translateY: -5,
      } : undefined}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={`
        relative overflow-hidden rounded-2xl
        bg-[rgba(15,40,71,0.7)] backdrop-blur-xl
        border border-[rgba(212,165,116,0.15)]
        shadow-xl shadow-black/10
        ${glow ? 'hover:shadow-[#d4a574]/10' : ''}
        ${className}
      `}
    >
      {/* Inner glow effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/[0.03] to-transparent pointer-events-none" />
      
      {/* Content */}
      <div className="relative z-10">{children}</div>
      
    </motion.div>
  );
}
