'use client';

import { motion } from 'framer-motion';

interface GradientTextProps {
  children: React.ReactNode;
  className?: string;
  from?: string;
  to?: string;
}

export default function GradientText({ 
  children, 
  className = '',
  from = '#d4a574',
  to = '#e8c9a0'
}: GradientTextProps) {
  return (
    <motion.span
      initial={{ backgroundPosition: '0% 50%' }}
      whileHover={{ backgroundPosition: '100% 50%' }}
      transition={{ duration: 0.3 }}
      className={`bg-gradient-to-r from-[${from}] via-[${to}] to-[${from}] bg-clip-text text-transparent bg-[length:200%_auto] ${className}`}
      style={{
        backgroundImage: `linear-gradient(90deg, ${from}, ${to}, ${from})`,
      }}
    >
      {children}
    </motion.span>
  );
}
