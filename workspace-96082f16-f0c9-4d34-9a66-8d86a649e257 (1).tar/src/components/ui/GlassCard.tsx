'use client';

import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { ReactNode, useRef, useState } from 'react';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  variant?: 'default' | 'premium' | 'subtle' | 'intense';
  hover3D?: boolean;
  glowOnHover?: boolean;
  parallaxIntensity?: number;
}

const variantStyles = {
  default: 'bg-[#0f2847]/70 backdrop-blur-xl border border-gold/20',
  premium: 'bg-gradient-to-br from-[#0f2847]/80 to-[#1a365d]/60 backdrop-blur-2xl border border-gold/30',
  subtle: 'bg-[#0f2847]/40 backdrop-blur-md border border-gold/10',
  intense: 'bg-[#0a1628]/90 backdrop-blur-3xl border-2 border-gold/40'
};

export default function GlassCard({ 
  children, 
  className = '',
  variant = 'default',
  hover3D = false,
  glowOnHover = true,
  parallaxIntensity = 20
}: GlassCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  const springConfig = { stiffness: 300, damping: 30 };
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [parallaxIntensity, -parallaxIntensity]), springConfig);
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-parallaxIntensity, parallaxIntensity]), springConfig);
  
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current || !hover3D) return;
    
    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    x.set((e.clientX - centerX) / rect.width);
    y.set((e.clientY - centerY) / rect.height);
  };
  
  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
    setIsHovered(false);
  };

  return (
    <motion.div
      ref={ref}
      className={`
        relative rounded-2xl overflow-hidden
        ${variantStyles[variant]}
        ${className}
      `}
      style={hover3D ? {
        rotateX,
        rotateY,
        transformPerspective: 1000,
        transformStyle: 'preserve-3d'
      } : undefined}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      whileHover={{ scale: hover3D ? 1.02 : 1.01 }}
      transition={{ duration: 0.2 }}
    >
      {/* Animated glow effect */}
      {glowOnHover && (
        <motion.div
          className="absolute inset-0 pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: isHovered ? 1 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-gold/0 via-gold/10 to-gold/0" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(212,165,116,0.15),transparent_70%)]" />
        </motion.div>
      )}
      
      {/* Noise texture overlay */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.015]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`
        }}
      />
      
      {/* Content */}
      <div className="relative z-10" style={hover3D ? { transform: 'translateZ(50px)' } : undefined}>
        {children}
      </div>
      
      {/* Border shimmer effect */}
      <motion.div
        className="absolute inset-0 rounded-2xl pointer-events-none"
        style={{
          background: 'linear-gradient(90deg, transparent, rgba(212,165,116,0.3), transparent)',
          backgroundSize: '200% 100%'
        }}
        animate={{
          backgroundPosition: isHovered ? ['200% 0', '-200% 0'] : '200% 0'
        }}
        transition={{ duration: 1.5, ease: 'linear' }}
      />
    </motion.div>
  );
}

// Simplified version for static use
export function GlassCardStatic({ 
  children, 
  className = '',
  variant = 'default'
}: Omit<GlassCardProps, 'hover3D' | 'glowOnHover' | 'parallaxIntensity'>) {
  return (
    <div className={`
      relative rounded-2xl overflow-hidden
      ${variantStyles[variant]}
      ${className}
    `}>
      {/* Noise texture overlay */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.015]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`
        }}
      />
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}

// Glass button component
export function GlassButton({ 
  children, 
  className = '',
  onClick
}: { 
  children: ReactNode; 
  className?: string;
  onClick?: () => void;
}) {
  return (
    <motion.button
      className={`
        relative px-6 py-3 rounded-xl
        bg-gradient-to-r from-gold to-gold-light
        text-[#0a1628] font-semibold
        overflow-hidden
        ${className}
      `}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
    >
      <span className="relative z-10">{children}</span>
      
      {/* Shimmer effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
        initial={{ x: '-100%' }}
        whileHover={{ x: '100%' }}
        transition={{ duration: 0.6 }}
      />
    </motion.button>
  );
}
