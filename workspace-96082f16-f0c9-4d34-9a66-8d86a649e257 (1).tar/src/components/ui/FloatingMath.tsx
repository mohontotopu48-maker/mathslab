'use client';

import { motion } from 'framer-motion';
import { useMemo } from 'react';

interface FloatingSymbol {
  symbol: string;
  delay: number;
  duration: number;
  x: string;
  y: string;
  size: 'sm' | 'md' | 'lg' | 'xl';
  opacity: number;
  rotation: number;
}

const mathSymbols = [
  '∫', 'Σ', 'π', '√', '∞', 'Δ', 'θ', 'λ', 'α', 'β',
  '∂', '∇', '∈', '⊂', '∪', '∩', 'φ', 'ψ', 'Ω', 'Γ',
  'f(x)', 'dx', 'dy', 'x²', '∑', '∏', '÷', '×', '±', '≠',
  '≤', '≥', '≈', 'lim', 'log', 'sin', 'cos', 'tan', 'e^x', 'ln'
];

const sizeClasses = {
  sm: 'text-2xl md:text-3xl',
  md: 'text-3xl md:text-4xl',
  lg: 'text-4xl md:text-5xl',
  xl: 'text-5xl md:text-6xl'
};

interface FloatingMathProps {
  count?: number;
  variant?: 'default' | 'dense' | 'sparse';
  color?: string;
  className?: string;
}

export default function FloatingMath({ 
  count = 15, 
  variant = 'default',
  color = '#d4a574',
  className = ''
}: FloatingMathProps) {
  const symbols = useMemo<FloatingSymbol[]>(() => {
    const density = variant === 'dense' ? count * 1.5 : variant === 'sparse' ? count * 0.6 : count;
    
    return Array.from({ length: Math.floor(density) }, (_, i) => ({
      symbol: mathSymbols[i % mathSymbols.length],
      delay: Math.random() * 5,
      duration: 5 + Math.random() * 5,
      x: `${Math.random() * 100}%`,
      y: `${Math.random() * 100}%`,
      size: ['sm', 'md', 'lg', 'xl'][Math.floor(Math.random() * 4)] as FloatingSymbol['size'],
      opacity: 0.05 + Math.random() * 0.1,
      rotation: Math.random() * 360
    }));
  }, [count, variant]);

  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}>
      {symbols.map((symbol, index) => (
        <motion.div
          key={index}
          className={`absolute font-bold ${sizeClasses[symbol.size]}`}
          style={{ 
            left: symbol.x, 
            top: symbol.y,
            color: color,
            opacity: symbol.opacity,
            textShadow: `0 0 20px ${color}40`
          }}
          initial={{ 
            scale: 0,
            opacity: 0,
            rotate: symbol.rotation - 180
          }}
          animate={{
            y: [-30, 30, -30],
            x: [-10, 10, -10],
            rotate: [symbol.rotation - 5, symbol.rotation + 5, symbol.rotation - 5],
            scale: [1, 1.1, 1],
            opacity: [symbol.opacity, symbol.opacity * 1.5, symbol.opacity]
          }}
          transition={{
            duration: symbol.duration,
            delay: symbol.delay,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          {symbol.symbol}
        </motion.div>
      ))}
    </div>
  );
}

// Particle-based floating math for more sophisticated effects
export function FloatingMathParticles({ count = 30 }: { count?: number }) {
  const particles = useMemo(() => {
    return Array.from({ length: count }, (_, i) => ({
      symbol: mathSymbols[i % mathSymbols.length],
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 0.5 + Math.random() * 1,
      duration: 15 + Math.random() * 20,
      delay: Math.random() * 10
    }));
  }, [count]);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((particle, index) => (
        <motion.div
          key={index}
          className="absolute text-gold font-mono"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            fontSize: `${particle.size}rem`,
            opacity: 0.03
          }}
          animate={{
            y: [0, -1000],
            x: [0, (Math.random() - 0.5) * 200],
            rotate: [0, 360],
            opacity: [0, 0.08, 0]
          }}
          transition={{
            duration: particle.duration,
            delay: particle.delay,
            repeat: Infinity,
            ease: "linear"
          }}
        >
          {particle.symbol}
        </motion.div>
      ))}
    </div>
  );
}

// Orbiting math symbols
export function OrbitingMath({ radius = 200 }: { radius?: number }) {
  const orbitSymbols = useMemo(() => {
    return Array.from({ length: 8 }, (_, i) => ({
      symbol: mathSymbols[i],
      angle: (i / 8) * 360,
      duration: 20 + i * 2
    }));
  }, []);

  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      {orbitSymbols.map((item, index) => (
        <motion.div
          key={index}
          className="absolute text-2xl font-bold text-gold/20"
          style={{
            transform: `rotate(${item.angle}deg) translateX(${radius}px)`
          }}
          animate={{
            rotate: [item.angle, item.angle + 360]
          }}
          transition={{
            duration: item.duration,
            repeat: Infinity,
            ease: "linear"
          }}
        >
          {item.symbol}
        </motion.div>
      ))}
    </div>
  );
}
