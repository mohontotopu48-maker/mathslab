'use client';

import { motion } from 'framer-motion';
import { ReactNode } from 'react';

interface GradientTextProps {
  children: ReactNode;
  className?: string;
  variant?: 'gold' | 'premium' | 'success' | 'rainbow' | 'custom';
  animate?: boolean;
  from?: string;
  via?: string;
  to?: string;
}

const gradientVariants = {
  gold: 'from-[#d4a574] via-[#e8c9a0] to-[#d4a574]',
  premium: 'from-[#d4a574] via-[#f0d9b5] to-[#b8956a]',
  success: 'from-emerald-400 via-emerald-300 to-teal-400',
  rainbow: 'from-purple-400 via-pink-400 to-orange-400',
  custom: ''
};

export default function GradientText({ 
  children, 
  className = '',
  variant = 'gold',
  animate = true,
  from,
  via,
  to
}: GradientTextProps) {
  const customGradient = from && to 
    ? `from-[${from}] ${via ? `via-[${via}]` : ''} to-[${to}]`
    : '';

  return (
    <motion.span
      className={`
        inline-block bg-gradient-to-r bg-clip-text text-transparent
        ${variant === 'custom' ? customGradient : gradientVariants[variant]}
        ${className}
      `}
      style={{
        backgroundSize: animate ? '200% auto' : '100%'
      }}
      animate={animate ? {
        backgroundPosition: ['0% center', '200% center']
      } : undefined}
      transition={{
        duration: 3,
        repeat: Infinity,
        ease: 'linear'
      }}
    >
      {children}
    </motion.span>
  );
}

// Animated text reveal with gradient
export function GradientTextReveal({
  children,
  className = '',
  delay = 0
}: {
  children: string;
  className?: string;
  delay?: number;
}) {
  const words = children.split(' ');

  return (
    <span className={className}>
      {words.map((word, wordIndex) => (
        <span key={wordIndex} className="inline-block">
          {word.split('').map((char, charIndex) => (
            <motion.span
              key={charIndex}
              className="inline-block bg-gradient-to-r from-[#d4a574] via-[#e8c9a0] to-[#d4a574] bg-clip-text text-transparent"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.3,
                delay: delay + wordIndex * 0.05 + charIndex * 0.02
              }}
            >
              {char}
            </motion.span>
          ))}
          {wordIndex < words.length - 1 && '\u00A0'}
        </span>
      ))}
    </span>
  );
}

// Glowing text effect
export function GlowingText({
  children,
  className = '',
  color = '#d4a574'
}: {
  children: ReactNode;
  className?: string;
  color?: string;
}) {
  return (
    <motion.span
      className={`relative ${className}`}
      animate={{
        textShadow: [
          `0 0 10px ${color}40`,
          `0 0 20px ${color}60`,
          `0 0 10px ${color}40`
        ]
      }}
      transition={{ duration: 2, repeat: Infinity }}
    >
      {children}
    </motion.span>
  );
}

// Typewriter effect with gradient
export function TypewriterGradient({
  text,
  className = '',
  speed = 50
}: {
  text: string;
  className?: string;
  speed?: number;
}) {
  const characters = text.split('');

  return (
    <span className={className}>
      {characters.map((char, index) => (
        <motion.span
          key={index}
          className="inline-block bg-gradient-to-r from-[#d4a574] to-[#e8c9a0] bg-clip-text text-transparent"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{
            duration: 0.1,
            delay: index * (speed / 1000)
          }}
        >
          {char}
        </motion.span>
      ))}
    </span>
  );
}

// Shimmer text effect
export function ShimmerText({
  children,
  className = ''
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <span className={`relative inline-block ${className}`}>
      <span className="bg-gradient-to-r from-white via-white to-white bg-clip-text text-transparent">
        {children}
      </span>
      <motion.span
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/60 to-transparent bg-clip-text text-transparent"
        style={{ backgroundSize: '200% 100%' }}
        animate={{
          backgroundPosition: ['-200% 0', '200% 0']
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          repeatDelay: 1
        }}
      >
        {children}
      </motion.span>
    </span>
  );
}
