'use client';

import { motion, useSpring, useInView, useTransform } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';

interface AnimatedCounterProps {
  target: number;
  suffix?: string;
  prefix?: string;
  duration?: number;
  className?: string;
  delay?: number;
  decimals?: number;
  formatNumber?: boolean;
}

export default function AnimatedCounter({ 
  target, 
  suffix = '', 
  prefix = '',
  duration = 2,
  className = '',
  delay = 0,
  decimals = 0,
  formatNumber = true
}: AnimatedCounterProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [hasAnimated, setHasAnimated] = useState(false);
  
  const spring = useSpring(0, {
    stiffness: 50,
    damping: 30,
    duration: duration * 1000
  });
  
  const display = useTransform(spring, (current) => {
    const value = current.toFixed(decimals);
    if (formatNumber) {
      return parseFloat(value).toLocaleString();
    }
    return value;
  });

  useEffect(() => {
    if (isInView && !hasAnimated) {
      const timer = setTimeout(() => {
        spring.set(target);
        setHasAnimated(true);
      }, delay * 1000);
      return () => clearTimeout(timer);
    }
  }, [isInView, target, spring, delay, hasAnimated]);

  return (
    <span ref={ref} className={className}>
      <motion.span>{prefix}</motion.span>
      <motion.span>{display}</motion.span>
      <motion.span>{suffix}</motion.span>
    </span>
  );
}

// Counter with progress bar
export function CounterWithProgress({
  target,
  max,
  label,
  color = '#d4a574'
}: {
  target: number;
  max: number;
  label: string;
  color?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true });
  const percentage = (target / max) * 100;
  
  return (
    <div ref={ref} className="space-y-2">
      <div className="flex justify-between items-end">
        <span className="text-gray-400 text-sm">{label}</span>
        <AnimatedCounter 
          target={target} 
          suffix={` / ${max}`} 
          className="text-white font-semibold"
        />
      </div>
      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: color }}
          initial={{ width: 0 }}
          animate={{ width: isInView ? `${percentage}%` : 0 }}
          transition={{ duration: 1.5, delay: 0.3, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}

// Stats grid component
export function StatsGrid({ stats }: { 
  stats: Array<{ value: number; label: string; suffix?: string; prefix?: string }> 
}) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.1 }}
          className="text-center"
        >
          <div className="text-3xl md:text-4xl font-bold gradient-text mb-1">
            <AnimatedCounter 
              target={stat.value} 
              suffix={stat.suffix} 
              prefix={stat.prefix}
              delay={index * 0.1}
            />
          </div>
          <p className="text-gray-400 text-sm">{stat.label}</p>
        </motion.div>
      ))}
    </div>
  );
}

// Circular progress counter
export function CircularProgressCounter({
  target,
  max,
  label,
  size = 120,
  strokeWidth = 8,
  color = '#d4a574'
}: {
  target: number;
  max: number;
  label: string;
  size?: number;
  strokeWidth?: number;
  color?: string;
}) {
  const ref = useRef<SVGSVGElement>(null);
  const isInView = useInView(ref, { once: true });
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const percentage = (target / max) * 100;
  
  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg 
          ref={ref}
          width={size} 
          height={size} 
          className="transform -rotate-90"
        >
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="rgba(255,255,255,0.1)"
            strokeWidth={strokeWidth}
            fill="none"
          />
          {/* Progress circle */}
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={color}
            strokeWidth={strokeWidth}
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ 
              strokeDashoffset: isInView 
                ? circumference - (percentage / 100) * circumference 
                : circumference 
            }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            style={{
              filter: `drop-shadow(0 0 6px ${color})`
            }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <AnimatedCounter 
            target={target} 
            suffix="%" 
            className="text-2xl font-bold text-white"
          />
        </div>
      </div>
      <p className="text-gray-400 text-sm mt-2">{label}</p>
    </div>
  );
}
