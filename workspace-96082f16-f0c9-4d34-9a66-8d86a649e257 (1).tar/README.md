# Maths Lab - O & A Level Mathematics Tutoring Website

A premium, modern educational website for international O & A Level Mathematics tutoring (Cambridge & Edexcel curriculum).

## 🚀 Vercel Deployment

### Quick Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/maths-lab)

### Manual Deployment

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/maths-lab.git
   cd maths-lab
   ```

2. **Install dependencies**
   ```bash
   bun install
   # or
   npm install
   ```

3. **Set up environment variables**
   - Copy `.env.example` to `.env`
   - For Vercel, add environment variables in your project settings:
     - `DATABASE_URL`: Your database connection string (optional - falls back to in-memory storage)

4. **Deploy to Vercel**
   ```bash
   vercel deploy
   ```

## 🗄️ Database Setup (Optional)

The app works without a database (uses in-memory storage for demo), but for production you should set up a database:

### Option 1: Vercel Postgres
```bash
vercel postgres create
```

### Option 2: Neon (Serverless Postgres)
1. Create account at [neon.tech](https://neon.tech)
2. Get your connection string
3. Add as `DATABASE_URL` environment variable

### Option 3: Supabase
1. Create project at [supabase.com](https://supabase.com)
2. Get connection string from project settings
3. Add as `DATABASE_URL` environment variable

## 📁 Project Structure

```
src/
├── app/
│   ├── page.tsx          # Main page
│   ├── layout.tsx        # Root layout
│   ├── globals.css       # Global styles
│   └── api/leads/        # API routes
├── components/
│   ├── sections/         # Page sections
│   │   ├── Navigation.tsx
│   │   ├── HeroSection.tsx
│   │   ├── AboutSection.tsx
│   │   ├── CoursesSection.tsx
│   │   ├── InternationalSection.tsx
│   │   ├── ResultsSection.tsx
│   │   ├── MethodologySection.tsx
│   │   ├── WhyChooseSection.tsx
│   │   ├── LeadFormSection.tsx
│   │   └── Footer.tsx
│   └── ui/custom/        # Custom UI components
│       ├── LoadingScreen.tsx
│       ├── GlassCard.tsx
│       ├── FloatingMath.tsx
│       ├── AnimatedCounter.tsx
│       ├── GradientText.tsx
│       └── WhatsAppButton.tsx
└── lib/
    └── db.ts             # Database client
```

## ✨ Features

- 🎨 Premium dark blue + gold theme
- 🔄 3D animated math elements
- 📱 Fully responsive design
- ⚡ Loading animations
- 🎯 Lead capture form with validation
- 🌍 International student support
- 💬 WhatsApp integration
- 🔍 SEO optimized

## 🛠 Tech Stack

- **Framework**: Next.js 16 with App Router
- **Language**: TypeScript
- **Styling**: Tailwind CSS 4
- **UI Components**: shadcn/ui
- **Animations**: Framer Motion
- **Database**: Prisma ORM
- **Icons**: Lucide React

## 🔧 Development

```bash
# Install dependencies
bun install

# Run development server
bun run dev

# Build for production
bun run build

# Run linting
bun run lint
```

## 📝 Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | Database connection string | No (falls back to memory) |

## 📄 License

MIT License - feel free to use for your own projects!

---

Built with ❤️ for students worldwide
